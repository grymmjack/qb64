
======================================================================
              Zu den geschainten EXE-Programmen
======================================================================

Das BAS-Dateien m�ssen bei QuickBasic 4.5 unbedingt mit der Option
"EXE, die BRUN45.EXE ben�tigt" zu EXE-Dateien kompiliert werden.
Das Laufzeitmodul BRUN45.EXE muss sich in demselben Verzeichnis wie
die ausf�hrbaren Dateien befinden und zusammen mit diesen weitergegeben
werden.

Der Name der Zieldatei wurde im CHAIN-Befehl jeweils von .BAS in
.EXE ge�ndert. Ansonsten blieben die BAS-Dateien gegen�ber der
interpretierten Version unver�ndert.

T.Antoni, 14.8.2003